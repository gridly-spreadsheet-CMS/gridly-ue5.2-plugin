﻿// Copyright (c) 2021 LocalizeDirect AB

#include "GridlyDataTable.h"
